package com.yang.guseokgi.dto.Inform;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InformAjax {

    private String id;

}
