package com.yang.guseokgi.dto.account;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountProfile {

    private Long accountId;

    private Long allPost;

    private Long sellingPost;

    private Long soldPost;

}
