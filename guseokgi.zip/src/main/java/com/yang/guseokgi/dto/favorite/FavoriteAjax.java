package com.yang.guseokgi.dto.favorite;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FavoriteAjax {

    private String postId;
    private String accountId;

}
