package com.yang.guseokgi.dto.favorite;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FavoriteIdAjax {
    private String id;
}
