package com.yang.guseokgi.dto.inquiry;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InquiryAjax {

    private String id;

    private String text;

}
