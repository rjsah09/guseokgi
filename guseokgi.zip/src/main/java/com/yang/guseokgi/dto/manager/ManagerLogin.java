package com.yang.guseokgi.dto.manager;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerLogin {

    private String uid;

    private String password;

}
