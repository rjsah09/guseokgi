package com.yang.guseokgi.dto.notification;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NotificationDeleteId {
    private String id;
}
