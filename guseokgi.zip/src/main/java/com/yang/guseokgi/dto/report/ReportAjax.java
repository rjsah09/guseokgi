package com.yang.guseokgi.dto.report;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReportAjax {
    private String id;
}
