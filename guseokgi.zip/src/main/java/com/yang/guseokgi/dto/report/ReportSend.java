package com.yang.guseokgi.dto.report;

import com.yang.guseokgi.domain.Account;
import com.yang.guseokgi.domain.category.ReportCategory;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReportSend {

    private ReportCategory reportCategory;

}
