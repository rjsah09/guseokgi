package com.yang.guseokgi.dto.trade;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TradeAJAX {

    private String tradeId;
    private String accountId;
    private String request;

}
