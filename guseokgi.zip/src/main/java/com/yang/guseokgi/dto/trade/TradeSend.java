package com.yang.guseokgi.dto.trade;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TradeSend {

    private Long postId;

}
