package com.yang.guseokgi.repository;

import com.yang.guseokgi.domain.ChatImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatImgRepository extends JpaRepository<ChatImg, Long> {

}
